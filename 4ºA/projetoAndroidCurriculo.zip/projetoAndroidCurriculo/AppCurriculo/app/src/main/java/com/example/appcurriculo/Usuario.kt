package com.example.appcurriculo

data class Usuario (
    val nome: String,
    val github: String,
    val linkedin: String,
    val empresa: String,
    val cargo: String,
    val faculdade: String,
    val curso: String,
    val email: String,
    val senha: String
)
