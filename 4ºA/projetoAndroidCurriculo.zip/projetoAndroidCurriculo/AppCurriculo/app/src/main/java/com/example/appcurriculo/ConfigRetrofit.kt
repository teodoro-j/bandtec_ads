package com.example.appcurriculo

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ConfigRetrofit {
    val retrofit = Retrofit.Builder()
            .baseUrl("https://5f9750f642706e0016956f54.mockapi.io/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    fun requestApi() = retrofit.create(RequestUsuarioController::class.java)
}