package com.example.appcurriculo

data class Login (
    val id: String,
    val email: String,
    val senha: String
)