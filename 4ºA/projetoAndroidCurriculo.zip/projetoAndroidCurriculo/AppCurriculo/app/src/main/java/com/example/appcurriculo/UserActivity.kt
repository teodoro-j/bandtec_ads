package com.example.appcurriculo

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_user.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        val extras = intent.extras
        if (extras != null) {
            val `in` = intent

            var id = `in`.getStringExtra("id")

            val api = ConfigRetrofit().requestApi()

            val call = api.getUsuario(id)

            call.enqueue(object : Callback<List<Usuario>> {

                override fun onResponse(call: Call<List<Usuario>>, response: Response<List<Usuario>>) {
                    response.body()?.forEach{
                        titulo_user.text = "${it.nome}"
                        user_git.text = "${it.github}"
                        user_linkedin.text = "${it.linkedin}"
                        user_empresa.text = "${it.empresa}"
                        user_cargo.text = "${it.cargo}"
                        user_faculdade.text = "${it.faculdade}"
                        user_curso.text = "${it.curso}"
                    }
                }
                override fun onFailure(call: Call<List<Usuario>>, t: Throwable) {
                    Toast.makeText(
                        applicationContext, "${R.string.toast_user_failure} ${t}",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            })
        }
    }

    fun deleteUsuraio(button: View) {
        val extras = intent.extras
        if (extras != null) {
            val `in` = intent

            var id = `in`.getStringExtra("id")

            val api = ConfigRetrofit().requestApi()

            val call = api.deleteUsuario(id)

            call.enqueue(object : Callback<Void> {

                override fun onResponse(call: Call<Void>, response: Response<Void>) {
                    Toast.makeText(
                        applicationContext,
                        R.string.toast_user_delete,
                        Toast.LENGTH_SHORT
                    ).show()
                    goBackRegister()
                }
                override fun onFailure(call: Call<Void>, t: Throwable) {
                    Toast.makeText(
                        applicationContext,
                        "${R.string.toast_user_delete_failure} ${t}",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            })
        }
    }

    fun goBackHome(button: View){
        val goBack = Intent(this, MainActivity::class.java)
        startActivity(goBack)
    }

    fun goBackRegister(){
        val goRegister = Intent(this, RegisterActivity::class.java)
        startActivity(goRegister)
    }
}