package com.example.appcurriculo

import android.content.Intent
import android.content.LocusId
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_register.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun goToAddUser(button: View){
        val addUser = Intent(this, RegisterActivity::class.java)
        startActivity(addUser)
    }

    fun criarCadastro(button: View) {
        val api = ConfigRetrofit().requestApi()

        val call = api.getLogin()

        call.enqueue(object: Callback<List<Login>> {

            override fun onResponse(call: Call<List<Login>>, response: Response<List<Login>>) {
                Toast.makeText(applicationContext, R.string.toast_main_login, Toast.LENGTH_SHORT).show()
                response.body()?.forEach {
                   if(et_cadastro_email.text.toString() == it.email && et_cadastro_senha.text.toString() == it.senha) {
                       telaUsuario(it.id)
                   } else {
                       Toast.makeText(applicationContext, R.string.toast_main_login_else, Toast.LENGTH_SHORT).show()
                   }
                }
            }

            override fun onFailure(call: Call<List<Login>>, t: Throwable) {
                Toast.makeText(applicationContext, "${R.string.toast_main_login_failure} $t", Toast.LENGTH_SHORT).show()
            }

        })
    }

    fun telaUsuario(id: String) {
        val insideUser = Intent(this, UserActivity::class.java)
        insideUser.putExtra("id", id)
        startActivity(insideUser)
    }

}
