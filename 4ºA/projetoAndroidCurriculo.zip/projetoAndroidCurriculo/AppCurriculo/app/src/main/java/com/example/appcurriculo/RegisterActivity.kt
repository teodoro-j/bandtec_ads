package com.example.appcurriculo

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_register.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
    }

    fun goToHome(button: View){
        criarCadastro()

        val home = Intent(this, MainActivity::class.java)
        startActivity(home)
    }

    fun criarCadastro() {
        val api = ConfigRetrofit().requestApi()

        val usuario = Usuario(et_cadastro_nome.text.toString(),et_cadastro_git.text.toString()
        ,et_cadastro_linkedin.text.toString(),et_cadastro_empresa.text.toString()
        ,et_cadastro_cargo.text.toString(),et_cadastro_faculdade.text.toString()
        ,et_cadastro_curso.text.toString(),et_cadastro_email.text.toString(),et_cadastro_senha.text.toString())

        val call = api.postUsuario(usuario)

        call.enqueue(object: Callback<Void> {

            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                Toast.makeText(applicationContext, R.string.toast_regester_response, Toast.LENGTH_SHORT).show()
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                Toast.makeText(applicationContext,  "${R.string.toast_regester_failure} ${t}", Toast.LENGTH_SHORT).show()
            }

        })
    }
}

