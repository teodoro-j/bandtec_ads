package com.example.appcurriculo

import retrofit2.Call
import retrofit2.http.*

interface RequestUsuarioController {
    @GET("usuario/{id}")
    fun getUsuario(@Path("id") id:String?): Call<List<Usuario>>

    @POST("usuario")
    fun postUsuario(@Body user: Usuario): Call<Void>

    @POST("usuario")
    fun getLogin(): Call<List<Login>>

    @DELETE("usuario/{id}")
    fun deleteUsuario(@Path("id") id:String?): Call<Void>
}