package br.com.bandtec.scrolleclienterest_turmaa

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.TypedValue
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // criando um objeto do tipo TextView
        val novoTv = TextView(baseContext)
        // baseContext é para "atrelar" o componete à Activity atual

        // configurando a TextView
        novoTv.text = "Meu texto em tempo de execução"
        novoTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        novoTv.setTextColor(Color.parseColor("#FF0099"))

        // adicionando a TextView no LinearLayout
        ll_conteudo.addView(novoTv)
    }
}